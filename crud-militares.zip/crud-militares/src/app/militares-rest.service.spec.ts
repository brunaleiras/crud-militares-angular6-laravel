import { TestBed } from '@angular/core/testing';

import { MilitaresRestService } from './militares-rest.service';

describe('MilitaresRestService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: MilitaresRestService = TestBed.get(MilitaresRestService);
    expect(service).toBeTruthy();
  });
});
