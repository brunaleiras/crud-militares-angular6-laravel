import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders, HttpErrorResponse } from '@angular/common/http';
import { Observable, of } from 'rxjs';
import { map, catchError, tap } from 'rxjs/operators';

const endpoint = 'http://localhost:8000/api/';
const httpOptions = {
  headers: new HttpHeaders({
    'Content-Type':  'application/json'
  })
};

@Injectable({
  providedIn: 'root'
})
export class MilitaresRestService {

  constructor(private http: HttpClient) {}

  private extractData(res: Response) {
    let body = res;
    return body || { };
  }

  getMilitares(): Observable<any> {
    return this.http.get(endpoint + 'militars').pipe(
      map(this.extractData));
  }

  getMilitar(id): Observable<any> {
    return this.http.get(endpoint + 'militars/' + id).pipe(
      map(this.extractData));
  }

  novoMilitar(militar): Observable<any> {
    console.log(militar);
    return this.http.post<any>(endpoint + 'militars', JSON.stringify(militar), httpOptions).pipe(
      tap((militar) => console.log(`salvo militar w/ id=${militar.id}`)),
      catchError(this.handleError<any>('novoMilitar'))
    );
  }

  atualizarMilitar(id, militar): Observable<any> {
    return this.http.put(endpoint + 'militars/' + id, JSON.stringify(militar), httpOptions).pipe(
      tap(_ => console.log(`atualizado militar id=${id}`)),
      catchError(this.handleError<any>('atualizarMilitar'))
    );
  }

  deletarMilitar(id): Observable<any> {
    return this.http.delete<any>(endpoint + 'militars/' + id, httpOptions).pipe(
      tap(_ => console.log(`deletado militar id=${id}`)),
      catchError(this.handleError<any>('deletarMilitar'))
    );
  }

  private handleError<T> (operation = 'operation', result?: T) {
    return (error: any): Observable<T> => {

      console.error(error); // log to console instead

      console.log(`${operation} failed: ${error.message}`);

      return of(result as T);
    };
  }
}