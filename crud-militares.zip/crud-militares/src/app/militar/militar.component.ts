import { Component, OnInit } from '@angular/core';
import { MilitaresRestService } from '../militares-rest.service';
import { ActivatedRoute, Router } from '@angular/router';

export interface PeriodicElement {
  name: string;
  position: number;
  weight: number;
  symbol: string;
}

@Component({
  selector: 'app-militar',
  templateUrl: './militar.component.html',
  styleUrls: ['./militar.component.css']
})
export class MilitarComponent implements OnInit {

  militares:any = [];

  displayedColumns: string[] = ['nome', 'dataDeNascimento', 'servicoObrigatorio', 'patente', 'identidade', 'acoes'];
  dataSource:any = [];

  constructor(public rest:MilitaresRestService, private route: ActivatedRoute, private router: Router) {


   }

  ngOnInit() {
    this.getMilitares();
  }

  getMilitares() {
    this.militares = [];
    this.rest.getMilitares().subscribe((data: {}) => {
      console.log(data);
      this.militares = data;
    });
  }

  novo() {
    this.router.navigate(['/militar-novo']);
  }

  editar(id){

    this.router.navigate(['/militar-editar/'+id]);

  }

  detalhar(id){

    this.router.navigate(['/militar-detalhar/'+id]);

  }

  deletar(id, nome) {
  
    let resultado = confirm("Tem certeza que deseja excluir "+nome+" ?");

    if(resultado){
      this.rest.deletarMilitar(id)
        .subscribe(res => {
            this.getMilitares();
          }, (err) => {
            console.log(err);
          }
        );
    }

  }

}
