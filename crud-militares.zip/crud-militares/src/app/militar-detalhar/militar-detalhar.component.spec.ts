import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MilitarDetalharComponent } from './militar-detalhar.component';

describe('MilitarDetalharComponent', () => {
  let component: MilitarDetalharComponent;
  let fixture: ComponentFixture<MilitarDetalharComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MilitarDetalharComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MilitarDetalharComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
