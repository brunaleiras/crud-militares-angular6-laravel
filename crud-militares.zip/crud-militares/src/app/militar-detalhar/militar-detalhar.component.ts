import { Component, OnInit } from '@angular/core';
import { MilitaresRestService } from '../militares-rest.service';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-militar-detalhar',
  templateUrl: './militar-detalhar.component.html',
  styleUrls: ['./militar-detalhar.component.css']
})
export class MilitarDetalharComponent implements OnInit {

  militarData:any;

  constructor(public rest:MilitaresRestService, private route: ActivatedRoute, private router: Router) { }

  ngOnInit() {
    this.rest.getMilitar(this.route.snapshot.params['id']).subscribe((data: any) => {
      this.militarData = data.data;
    });
  }

}