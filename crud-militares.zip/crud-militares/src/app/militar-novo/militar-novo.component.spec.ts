import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MilitarNovoComponent } from './militar-novo.component';

describe('MilitarNovoComponent', () => {
  let component: MilitarNovoComponent;
  let fixture: ComponentFixture<MilitarNovoComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MilitarNovoComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MilitarNovoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
