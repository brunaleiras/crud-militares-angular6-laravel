import { Component, OnInit, Input } from '@angular/core';
import { MilitaresRestService } from '../militares-rest.service';
import { ActivatedRoute, Router } from '@angular/router';
import { FormBuilder, FormGroup, Validators} from '@angular/forms';

@Component({
  selector: 'app-militar-novo',
  templateUrl: './militar-novo.component.html',
  styleUrls: ['./militar-novo.component.css']
})
export class MilitarNovoComponent implements OnInit {

  @Input() militarData:any = { nome:'', dataDeNascimento: '', servicoObrigatorio: '', patente: '', identidade: '' };

  options: FormGroup;
  
  constructor(public rest:MilitaresRestService, private route: ActivatedRoute, private router: Router) { 

  }

  ngOnInit() {
  }

  novoMilitar() {

    this.rest.novoMilitar(this.militarData).subscribe((result) => {
      this.router.navigate(['/militares']);
    }, (err) => {
      console.log(err);
    });

  }

  getFontSize() {
    return Math.max(10, this.options.value.fontSize);
  }

}
