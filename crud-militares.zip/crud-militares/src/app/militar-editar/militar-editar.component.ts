import { Component, OnInit, Input } from '@angular/core';
import { MilitaresRestService } from '../militares-rest.service';
import { ActivatedRoute, Router } from '@angular/router';

export interface Food {
  value: string;
  viewValue: string;
}

@Component({
  selector: 'app-militar-editar',
  templateUrl: './militar-editar.component.html',
  styleUrls: ['./militar-editar.component.css']
})
export class MilitarEditarComponent implements OnInit {

  @Input() militarData:any = { nome: '', dataDeNascimento: '', servicoObrigatorio: '', patente: '', identidade: '' };

  foods: Food[] = [
    {value: 'soldado', viewValue: 'soldado'},
    {value: 'cabo', viewValue: 'cabo'},
    {value: 'sargento', viewValue: 'sargento'},
    {value: 'subtenente', viewValue: 'subtenente'},
    {value: 'tenente', viewValue: 'tenente'},
    {value: 'capitao', viewValue: 'capitao'},
    {value: 'general', viewValue: 'general'},
  ];

  patenteSelecionada:string;

  constructor(public rest:MilitaresRestService, private route: ActivatedRoute, private router: Router) { }

  ngOnInit() {
    this.rest.getMilitar(this.route.snapshot.params['id']).subscribe((data: any) => {

console.log("-------------LENDO----------------");
    console.log(data.data);
    console.log("-------------LENDO----------------");
      this.militarData = data.data;
    });
  }

  selecionarPatente(ev){

console.log("-------------EVENTO----------------");
console.log(ev);
console.log("-------------EVENTO----------------");


  }

  atualizarMilitar() {

console.log("-------------SALVANDO----------------");
console.log(this.militarData);
console.log("-------------SALVANDO----------------");

    this.rest.atualizarMilitar(this.route.snapshot.params['id'], this.militarData).subscribe((result) => {
      this.router.navigate(['/militares']);
    }, (err) => {
      console.log(err);
    });
  }

  listarMilitar(){
    this.router.navigate(['/militares']);
  }

}